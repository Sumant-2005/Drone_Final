%% Mission commands
% Time (s), forward (m/s), right (m/s), climb (m/s), yaw rate (deg/s)
mission = [
     0   2   0   0    0
     4   0   0   0    0
     7  -2   0   0    0
    11   0   0   0    0
    14   0   2   0    0
    18   0   0   0    0
    21   0  -2   0    0
    25   0   0   0    0
    28   0   0   1    0
    31   0   0   0    0
    34   0   0  -1    0
    37   0   0   0    0
    40   0   0   0   10
    43   0   0   0    0
    46   0   0   0  -10
    49   0   0   0    0
    52   0   0   0    0
];
flight_step = 0.00125;                 % s, flight controller period
stop_time = mission(end,1);            % s, end of the mission
start_height = 5;                      % m, initial hover height

%% Aircraft
mass = 300;                            % kg, total flying mass
gravity = 9.81;                        % m/s^2
inertia = [100; 100; 185];             % kg m^2, roll / pitch / yaw
arm = 1.1;                             % m, forward and lateral motor offsets
linear_drag = 20;                      % N per (m/s)
angular_drag = 50;                     % N m per (rad/s)

%% Propellers and mixer
diameter = 1;                          % m
air_density = 1.225;                   % kg/m^3
thrust_coefficient = 0.1;              % dimensionless, T = Ct*rho*n^2*D^4
rotor_time = 0.035;                    % s, first-order rotor response
thrust_factor = 1.1;                   % maximum thrust divided by hover thrust
disk_area = pi*diameter^2/4;           % m^2 per propeller
kT = thrust_coefficient*air_density*diameter^4/(2*pi)^2; % T = kT*omega^2
kQ = kT^1.5/sqrt(2*air_density*disk_area); % Q = kQ*omega^2, ideal static disk
hover_thrust = mass*gravity/4;         % N per propeller
max_thrust = thrust_factor*hover_thrust; % N per propeller
hover_speed = sqrt(hover_thrust/kT);   % rad/s
yaw_arm = kQ/kT;                       % torque per newton of thrust
% Columns are front right, back left, front left, back right.
force_matrix = [1 1 1 1; -arm arm arm -arm; arm -arm arm -arm; yaw_arm yaw_arm -yaw_arm -yaw_arm];
mixer_matrix = force_matrix\eye(4);    % collective + three moments to rotor thrusts

%% Flight controller
speed_gain = 0.85;                     % 1/s, horizontal speed error to acceleration
height_gain = 0.85;                    % 1/s, height error to climb speed
climb_gain = 1.6;                      % 1/s, climb speed error to acceleration
tilt_gain = 2.4;                       % 1/s, tilt angle error to body rate
rate_gain = [6; 6; 3];                 % 1/s, roll / pitch / yaw rate feedback
max_acceleration = 1.4;                % m/s^2, horizontal acceleration limit

%% Values read by the block diagram
movement_gains = diag([speed_gain speed_gain height_gain]);
% Feed forward horizontal drag and the pilot's climb speed.
movement_feedforward = diag([linear_drag/mass linear_drag/mass 1])*eye(3,5);
tilt_climb_gains = diag([tilt_gain tilt_gain climb_gain]);
rate_to_moment = diag(inertia.*rate_gain);
rotor_to_loads = force_matrix*kT;
inverse_rotor_time = 1/rotor_time;
vehicle = [mass; gravity; linear_drag];
mechanical = [inertia; angular_drag];
initial_body = [0; 0; -start_height; zeros(9,1)]; % NED position, velocity, angles, rates
initial_rotors = hover_speed*ones(4,1); % rad/s
