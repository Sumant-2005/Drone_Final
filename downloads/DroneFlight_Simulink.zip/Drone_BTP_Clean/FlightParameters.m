% DroneFlight and EMRAXDrive share these settings. Units are given on every row.
% Change a mission time or command below, save this file, then press Run.

%% Flight plan
drone.initial_height_m = 5;   % m above the ground at the start
drone.step_s = 0.00125;       % s per flight controller update
% Each row takes effect at the time in its first column.
% Time (s)   Forward (m/s)   Right (m/s)   Climb (m/s)   Turn right (deg/s)
drone.mission = [
     0   2   0   0    0    % Fly forward
     4   0   0   0    0    % Brake and hover
     7  -2   0   0    0    % Fly backward
    11   0   0   0    0    % Hover
    14   0   2   0    0    % Fly right
    18   0   0   0    0    % Hover
    21   0  -2   0    0    % Fly left
    25   0   0   0    0    % Hover
    28   0   0   1    0    % Climb
    31   0   0   0    0    % Hold the new height
    34   0   0  -1    0    % Descend
    37   0   0   0    0    % Hold the original height
    40   0   0   0   10    % Turn right
    43   0   0   0    0    % Stop turning
    46   0   0   0  -10    % Turn left
    49   0   0   0    0    % Final hover
    52   0   0   0    0    % End of mission
];

%% Aircraft and air
drone.mass_kg = 300;                         % kg, loaded aircraft
drone.inertia_kg_m2 = [100; 100; 185];        % kg m^2, roll / pitch / yaw
drone.arm_projection_m = 1.1;                % m, fore-aft and lateral motor offsets
drone.gravity_m_s2 = 9.81;                   % m/s^2, downward acceleration
drone.air_density_kg_m3 = 1.225;             % kg/m^3, ambient air density
drone.linear_drag_N_per_m_s = 20;            % N per m/s of translation
drone.angular_drag_Nm_per_rad_s = 50;        % N m per rad/s of rotation

%% Rotors
drone.rotors = 4;                            % rotor count
drone.diameter_m = 1.0;                      % m, propeller tip to tip
drone.thrust_coefficient = 0.1;              % dimensionless propeller coefficient
drone.sizing_weight_factor = 1.1;            % max thrust per rotor / hover thrust
drone.speed_lag_s = 0.035;                   % s, rotor-speed time constant in flight model

%% Proportional feedback gains and acceleration limit
drone.velocity_gain_per_s = 0.85;            % 1/s, horizontal speed error to acceleration
drone.max_accel_m_s2 = 1.4;                  % m/s^2, total horizontal acceleration limit
drone.height_gain_per_s = 0.85;              % 1/s, height error to climb speed
drone.climb_gain_per_s = 1.6;                % 1/s, climb speed error to acceleration
drone.tilt_gain_per_s = 2.4;                 % 1/s, tilt angle error to body rate
drone.rate_gain_per_s = [6; 6; 3];           % 1/s, roll / pitch / yaw rate error to acceleration
